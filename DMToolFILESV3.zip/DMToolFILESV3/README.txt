Author: Soren Emmons

Hi, this is the DMtool it is meant to aid in some of the more tedious parts about 
being a DM. I hope to keep updating this program with more features and am 
always appreciate comments on how the code could be better and new features
that people would like to see added. This program is meant to be very versatile and customizetiable.
All you need to do to customize the tables that are used is to just edit the
text files. If you want to add or delete something make sure to edit the number at the 
top of the text file as it is used to determine how big the array is that holds all the information
if it is not changed the program will be prone to crashes. As well as make sure that when running
the program it is in the same directory as the text files or you will get errors and the program 
will not display data as the text file names are hardcoded. 